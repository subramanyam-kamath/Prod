<a name="readme-top"></a>

![Build Status](https://github.com/devforce/TA-LMS/actions/workflows/FeatureBranch.yml/badge.svg)

<br />
<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li><a href="#about-the-project">About The Project</a></li>
    <li><a href="#prerequisites">Prerequisites</a></li>
    <li><a href="#scratch-org-setup">Scratch Org Setup</a></li>
  </ol>
</details>

## About The Project

TrailHead Academy

## Prerequisites

-   Node version is 18.x.x
-   [Salesforce CLI][salesforce-cli-url] installed
-   [Install Salesforce Extensions for VS Code](https://developer.salesforce.com/tools/vscode/en/vscode-desktop/install).
-   JDK installed and configured in VS Code. Follow [Java Setup](https://developer.salesforce.com/tools/vscode/en/vscode-desktop/java-setup) for instructions. This is required for Prettier Apex plugin to work.

## Scratch Org Setup

1. Clone the repo
    ```sh
    git clone https://github.com/devforce/TA-LMS
    ```
2. ```sh
   npm install
   ```
3. ```sh
    npx gulp setupEnvironment --orgname=default-scratch-org  --maxdays=30
   ```
    This command does the below tasks:
    1. Spins up a scratch org.
    2. Deploys metadata from [force-app folder](./force-app).
    3. Publishes community.
    4. Creates finest DebugLevel and assigns to Admin users.
    5. Enables Lightning Debug Mode for admin users.

<!-- MARKDOWN LINKS & IMAGES -->

[salesforce-cli-url]: https://developer.salesforce.com/tools/sfdxcli
